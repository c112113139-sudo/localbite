LocalBite Premium Static Site
=============================

部署方式：
1. 將本資料夾或 ZIP 上傳至 Netlify Drop / Cloudflare Pages Direct Upload。
2. 或將 index.html 與 about6.html 上傳至 GitHub repository，開啟 GitHub Pages。
3. 首頁檔案為 index.html，第二頁為 about6.html。

注意：
- 這是靜態展示網站，購物車使用瀏覽器 localStorage 模擬。
- 尚未串接正式金流、訂單、會員與物流後台。
- YouTube Shorts 已在首頁以 iframe embed 方式直接顯示。
